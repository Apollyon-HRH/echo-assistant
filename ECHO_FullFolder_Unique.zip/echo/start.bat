@echo off
setlocal
cd /d %~dp0
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scriptsctivate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py --cli
pause
