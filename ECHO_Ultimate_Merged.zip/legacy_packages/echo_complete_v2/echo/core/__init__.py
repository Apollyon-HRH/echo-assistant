"""Core package for ECHO."""
